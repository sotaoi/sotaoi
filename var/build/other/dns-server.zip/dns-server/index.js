const { createServer, Packet } = require('./dns');

const PORT = 5333;

const server = createServer((request, send, rinfo) => {
  const response = Packet.createResponseFromRequest(request);
  const [question] = request.questions;
  const { name } = question;
  response.answers.push({
    name,
    type: Packet.TYPE.A,
    class: Packet.CLASS.IN,
    ttl: 300,
    address: '8.8.8.8',
  });
  send(response);
});

server.on('request', (request, response, rinfo) => {
  console.log(request.header.id, request.questions[0]);
});

server.listen(PORT);
console.log(`dns server listening on ${PORT}`);
