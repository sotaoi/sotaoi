import React from 'react';

export default () => {
  return <div>
    Template View
  </div>;
};