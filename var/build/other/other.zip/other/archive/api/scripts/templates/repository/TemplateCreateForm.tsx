import React from 'react';

export default (props: {children?: any}) => <div>
  <h3>Template Create Form</h3>

  {props.children}
</div>;