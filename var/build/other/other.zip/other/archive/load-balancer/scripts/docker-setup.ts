import { execSync } from 'child_process';
import InfoJson from '../../info.json';

const tag = InfoJson.packageName;

execSync(`docker build -t ${tag} .`, { stdio: 'inherit' });
execSync(`docker create --name ${tag} ${tag}`, { stdio: 'inherit' });