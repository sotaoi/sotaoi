import { execSync } from 'child_process';
import InfoJson from '../../info.json';

const tag = InfoJson.packageName;

execSync(`docker start ${tag}`, { stdio: 'inherit' });