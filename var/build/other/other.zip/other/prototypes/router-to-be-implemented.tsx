import React, {CSSProperties, SyntheticEvent} from 'react';
import {GestureResponderEvent, Text, TouchableOpacity, View} from 'react-native';
import {getClientType} from './StateHelper';

// todo here: update - create a redirect method that's similar to push route, but instead of pushing a new state, replace the existing one <-- dafuq did i mean by this?

type ComponentSet = {[key: string]: {[key: string]: any}};
type GetHomeUrlFn = (rstate: RouterState) => string;
type GetNotFoundFn = () => ReactComponent;
type LayoutFn = (display: React.ReactNode, rstate: RouterState) => React.ReactNode;
type PushFn = (rstate: RouterState, resetScroll?: boolean) => void;
type ReactComponent = React.FunctionComponent | React.ComponentClass;

const defaultResetScrollValue = false;

const state: {goBack: Function; goForward: Function; getHomeUrl: GetHomeUrlFn; push: PushFn; rerender: Function; rstate: () => RouterState} = {
    goBack: (): void => null,
    goForward: (): void => null,
    getHomeUrl: (rstate: RouterState) => null,
    push: (): void => null,
    rerender: (): void => null,
    rstate: () => null,
};
let navCanGoBack: boolean = false;
let navCanGoForward: boolean = false;

// let's join history and router, and make it common for both react for web and react-native for mobile :/

type RouteSet = {[key: string]: {component: any; condition?: (rstate: RouterState) => boolean}};
type RouterProps = {
    callback: Function;
    controllers: ComponentSet;
    notFound: GetNotFoundFn;
    state: RouterStateProps;
    getHomeUrl?: GetHomeUrlFn;
    routes?: RouteSet;
    layout?: LayoutFn;
};

class Router extends React.Component<RouterProps> {
    public callback: Function = (rstate: RouterState): void => null;
    public controllers: ComponentSet = {};
    public display: ReactComponent = null;
    public getHomeUrl: GetHomeUrlFn;
    public index: number;
    public layoutFn: LayoutFn;
    public mounted = false;
    public next: RouterState[] = [];
    public notFound: ReactComponent;
    public prev: RouterState[] = [];
    public routeSet: RouteSet;
    public rstate: RouterState;

    public constructor(props: RouterProps) {
        super(props);

        this.callback = props.callback;
        this.controllers = props.controllers;
        this.display = null;
        this.getHomeUrl = props.getHomeUrl ? props.getHomeUrl : (rstate: RouterState) => null;
        this.index = getClientType() === 'ctweb' && window.history.state ? window.history.state.index : 0;
        this.layoutFn = props.layout ? props.layout : (display: React.ReactNode = null, rstate: RouterState): React.ReactNode => display;
        this.notFound = props.notFound();
        this.routeSet = props.routes || {};

        if (getClientType() === 'ctweb') {
            window.addEventListener('popstate', (ev: PopStateEvent): void => {
                if (!ev.state) return;
                ev.state.index < this.index
                    ? this.jumpBack(ev.state.index, new RouterState(ev.state.rstate))
                    : this.jumpForward(ev.state.index, new RouterState(ev.state.rstate));
            });
        }

        this.rstate = new RouterState(props.state);

        state.goBack = () => this.jumpBack();
        state.goForward = () => this.jumpForward();
        state.getHomeUrl = () => this.getHomeUrl(this.rstate);
        state.push = (rstate: RouterState, resetScroll = defaultResetScrollValue) => this.push(rstate, resetScroll);
        state.rerender = () => this.rerender();
        state.rstate = () => this.rstate;

        this.procNavigateAttributes();
        getClientType() === 'ctweb' && !window.history.state && window.history.replaceState({
            index: this.index,
            rstate: {uri: this.rstate.uri},
            scrollTop: document.body.scrollTop || document.documentElement.scrollTop || 0,
        }, null, this.rstate.uri);
    }

    public componentDidMount(): void {
        this.mounted = true;
        this.renderRouteDisplay(this.rstate);
    }

    public componentWillUnmount(): void {
        this.mounted = false;
    }

    public jumpBack(index: number = null, rstate: RouterState = null): void {
        try {
            if (index === null) {
                switch (true) {
                case !navCanGoBack:
                    return;
                case getClientType() === 'ctweb' && this.index > 0:
                    window.history.back();
                    return;
                default:
                    index = this.index - 1;
                }
            }
            rstate = rstate ? rstate : this.prev[index];
            if (!rstate) {
                return;
            }
            this.next.unshift(this.rstate);
            this.prev = [...this.prev.slice(0, index), ...this.prev.slice(index + 1)];
            this.index = index;
            this.procNavigateAttributes();
            this.renderRouteDisplay(rstate);
        } catch (ex) {
            console.warn(ex);
        }
    }

    public jumpForward(index: number = null, rstate: RouterState = null): void {
        try {
            if (index === null) {
                switch (true) {
                case !navCanGoForward:
                    return;
                case getClientType() === 'ctweb':
                    window.history.forward();
                    return;
                default:
                    index = this.index + 1;
                }
            }
            const indexOfNext = index - this.prev.length - 1;
            rstate = rstate ? rstate : this.next[indexOfNext];
            if (!rstate) {
                return;
            }
            this.prev.push(this.rstate);
            this.next = [...this.next.slice(0, indexOfNext), ...this.next.slice(indexOfNext + 1)];
            this.index = index;
            this.procNavigateAttributes();
            this.renderRouteDisplay(rstate);
        } catch (ex) {
            console.warn(ex);
        }
    }

    public push(rstate: RouterState, resetScroll: boolean = defaultResetScrollValue): void {
        if (this.rstate && this.rstate.uri === rstate.uri) {
            getClientType() === 'ctweb' && !window.history.state && window.history.replaceState({
                index: this.index,
                rstate: {uri: this.rstate.uri},
                scrollTop: document.body.scrollTop || document.documentElement.scrollTop || 0,
            }, null, this.rstate.uri);
            return;
        }

        this.next = [];
        this.prev.push(this.rstate);
        this.index++;
        if (getClientType() === 'ctweb') window.history.pushState({
            index: this.index,
            rstate: {uri: rstate.uri},
            scrollTop: document.body.scrollTop || document.documentElement.scrollTop || 0,
        }, null, rstate.uri);
        this.procNavigateAttributes();

        this.renderRouteDisplay(rstate);

        if (getClientType() === 'ctweb' && resetScroll) {
            window.scrollTo({top: 0});
        }
    }

    public rerender(): void {
        this.mounted && this.forceUpdate();
    }

    protected renderRouteDisplay(rstate: RouterState): void {
        this.display = null;
        this.rstate = rstate;

        for (let [route, data] of Object.entries(this.routeSet)) {
            if (!rstate.isMatch(route)) {
                continue;
            }

            if (typeof data.condition === 'function' && !data.condition(rstate)) {
                this.display = this.notFound;
                break;
            }

            if (typeof data.component !== 'string') {
                this.display = data.component;
                break;
            }

            try {
                const split = data.component.split(':');
                this.display = this.controllers[split[0]][split[1]] || this.notFound;
                rstate.params = rstate.getParams(route) || {};
            } catch (ex) {
                console.warn(ex);
                this.display = this.notFound;
            }

            break;
        }

        this.display = this.display || this.notFound;
        this.rerender();
        this.callback(rstate);
    }

    protected procNavigateAttributes(): void {
        navCanGoBack = !!this.prev.length;
        navCanGoForward = !!this.next.length;
    }

    //

    public render(): React.ReactNode {
        if (!this.display) {
            return null;
        }
        return this.layoutFn(<this.display {...{rstate: this.rstate} as any}/>, this.rstate);
    }
}

//

type LinkProps = {children?: any; style?: CSSProperties; textAlign?: 'left' | 'center' | 'right'; to: string}
const Link = (props: LinkProps): React.ReactElement => {
    const to = props.to.charAt(0) === '/' ? props.to : `/${props.to}`;

    let i = -1;
    const children = React.Children.toArray(props.children).map(child => typeof child === 'string' ?
        <Text key={i++}>{child}</Text> : child);

    switch (getClientType()) {
    case 'ctweb':
        return <a onClick={ev => {
            ev.preventDefault();
            state.push(new RouterState({uri: to}), true);
            return false;
        }} href={to} style={{...props.style, cursor: 'pointer'}}>{children}</a>;
    case 'ctmobile':
        let align: 'flex-start' | 'center' | 'flex-end' = 'center';
        switch (true) {
        case props.textAlign === 'left':
            align = 'flex-start';
            break;
        case props.textAlign === 'right':
            align = 'flex-end';
            break;
        }
        return <View style={{flexDirection: 'row', justifyContent: align}}>
            <TouchableOpacity onPress={() => state.push(new RouterState({uri: to}), true)}>
                {children}
            </TouchableOpacity>
        </View>;
    }
};

//

type RouterStateProps = {uri: string; params?: any};

class RouterState {
    public params: any;
    public uri: string;

    public constructor(rstate: RouterStateProps) {
        this.uri = rstate.uri;
        this.params = rstate.params || null;
    }

    public isMatch<R>(uriScheme: string): boolean {
        let argMatches: RegExpMatchArray;
        try {
            argMatches = uriScheme.match(/{[^({}).]+}/g);
        } catch (ex) {
            return false;
        }
        const args = argMatches ? argMatches.map(uriScheme => uriScheme.replace(/[{}]/g, '')) : [];

        let regex = `^${uriScheme}$`;
        args.map(arg => {
            regex = regex.replace(`(/{${arg}})*`, '(/(.+))*');
            regex = regex.replace(`(/{${arg}})?`, '(/(.+))*');
            regex = regex.replace(`{${arg}}`, '([^/]+)');
        });

        let match: RegExpMatchArray;
        try {
            match = this.uri.match(regex);
        } catch (ex) {
            return false;
        }
        return !!match;
    }

    public getParams<R>(uriScheme: string): R {
        let argMatches: RegExpMatchArray;
        try {
            argMatches = uriScheme.match(/{[^({}).]+}/g);
        } catch (ex) {
            return {} as R;
        }
        const args = argMatches ? argMatches.map(uriScheme => uriScheme.replace(/[{}]/g, '')) : [];

        let regex = `^${uriScheme}$`;
        args.map(arg => {
            regex = regex.replace(`(/{${arg}})*`, '(/(.+))*');
            regex = regex.replace(`(/{${arg}})?`, '(/(.+))*');
            regex = regex.replace(`{${arg}}`, '([^/]+)');
        });

        const params = {};

        let index = -1;
        const result: string[] = [];
        let match: RegExpMatchArray;
        try {
            match = this.uri.match(regex);
        } catch (ex) {
            return {} as R;
        }
        match && match.map(match => {
            index++;
            if (index > 0 && match && match[0] !== '/') {
                result.push(match);
            }
        });

        index = -1;
        for (let item of args) {
            index++;
            params[item] = result && result[index] ? result[index] : null;
        }

        return params as R;
    }

    public goBack(): void {
        state.goBack();
    }

    public goForward(): void {
        state.goForward();
    }

    public rerender(): void {
        state.rerender();
    }
}

const BackButton = (props: {backgroundColor?: string, color?: string, component: React.ReactNode, onPress?: (ev: GestureResponderEvent | SyntheticEvent) => void, to?: string}): React.ReactElement => {
    const to = props.to
        ? props.to.charAt(0) === '/'
            ? props.to
            : `/${props.to}`
        : null;

    switch (getClientType()) {
    case 'ctweb':
        return <div style={{
            alignItems: 'center',
            backgroundColor: props.backgroundColor ? props.backgroundColor : 'transparent',
            cursor: 'pointer',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            padding: 6,
            width: 40,
        }} onClick={(ev: SyntheticEvent) => {
            to
                ? state.push(new RouterState({uri: to}), true)
                : props.onPress
                    ? props.onPress(ev)
                    : state.goBack();
        }}>{props.component}</div>;
    case 'ctmobile':
        return <TouchableOpacity
            hitSlop={{bottom: 5, left: 5, right: 5, top: 5}}
            style={{
                alignItems: 'center',
                backgroundColor: props.backgroundColor ? props.backgroundColor : 'transparent',
                justifyContent: 'center',
                padding: 10,
                width: 40,
            }}
            onPress={(ev) => {
                to
                    ? state.push(new RouterState({uri: to}), true)
                    : props.onPress
                        ? props.onPress(ev)
                        : state.goBack();
            }}
        >
            {props.component}
        </TouchableOpacity>;
    default:
        return null;
    }
};

const canGoBack = () => navCanGoBack;
const canGoForward = () => navCanGoForward;
const getHomeUrl = () => state.getHomeUrl(state.rstate());
const pushRoute = (uri: string) => state.push(new RouterState({uri}), true);
const rerender = () => state.rerender();

export default Router;
export {BackButton, canGoBack, canGoForward, getHomeUrl, Link, PushFn, pushRoute, rerender, RouterState, RouterStateProps};
